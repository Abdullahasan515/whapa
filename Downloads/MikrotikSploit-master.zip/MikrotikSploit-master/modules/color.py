#!/usr/bin/python3
# coding=utf-8
# *******************************************************************
# *** MikrotikSploit ***
# * Version:
#   v0.1
# * Date:
#   28 - 08 - 2019 { Wed 28 Aug 2019 }
# * Facebook:
#   http://fb.com/mhm.hack
# * Author:
#   Hathem Ahmed
# *******************************************************************

'''
Module Of Colors.
OS : Ubuntu
'''

# banner Colors
bannerblue = '\033[34m'
bannerblue2 = '\033[1;1;94m'
yellowhead = '\033[1;1;94m'

# default colors

R = '\033[31m'
P = '\033[34m'
W = '\033[37m'
B = '\033[36m'
WOW = '\033[7m'
F = '\033[5m'
F2 = '\033[4m'
N = '\033[0m'
T = '\033[93m'
Y = '\033[33m'


# test colors

failexploit = '\033[91mFAIL\033[0m'
vulnexploit = '\033[92mVULN\033[0m'
portopen = '\033[92mOPEN \033[0m'
portclose = '\033[91mCLOSE\033[0m'
